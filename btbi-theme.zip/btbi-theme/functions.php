<?php
defined('ABSPATH') || exit;

// ─── Theme support ───────────────────────────────────────────────────────────
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
});

// ─── Version bump this after every new React build upload ────────────────────
define('BTBI_REACT_VER', '1.0.0');

// ─── Helpers ─────────────────────────────────────────────────────────────────
function btbi_is_react_page(): bool {
    return is_front_page() || is_page_template('page-react-app.php');
}

function btbi_react_app_url(string $path = ''): string {
    return get_template_directory_uri() . '/react-app/' . $path;
}

// ─── Enqueue assets ──────────────────────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    $fonts_url = 'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700'
        . '&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,400'
        . '&family=Montserrat:wght@300;400;500;600;700'
        . '&family=Mrs+Saint+Delafield&display=swap';

    if (btbi_is_react_page()) {
        // Preconnect hints injected via wp_head filter below
        wp_enqueue_style('btbi-fonts', $fonts_url, [], null);
        wp_enqueue_style('btbi-app', btbi_react_app_url('assets/app.css'), ['btbi-fonts'], BTBI_REACT_VER);
        wp_enqueue_script('btbi-samcart', 'https://static.samcart.com/checkouts/sc-slide-script.js', [], null, false);
        wp_enqueue_script('btbi-app', btbi_react_app_url('assets/app.js'), [], BTBI_REACT_VER, true);
        // Dequeue default WP block styles — not needed for React pages
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('wp-block-library-theme');
        wp_dequeue_style('global-styles');
    } else {
        // Blog / archive pages still get brand fonts
        wp_enqueue_style('btbi-fonts', $fonts_url, [], null);
        wp_enqueue_style('btbi-blog', get_template_directory_uri() . '/blog.css', ['btbi-fonts'], BTBI_REACT_VER);
    }
});

// Add defer to SamCart (must be deferred, not in footer)
add_filter('script_loader_tag', function (string $tag, string $handle): string {
    if ($handle === 'btbi-samcart') {
        return str_replace(' src=', ' defer src=', $tag);
    }
    return $tag;
}, 10, 2);

// Inject font preconnect hints before wp_head styles
add_action('wp_head', function () {
    if (!btbi_is_react_page()) return;
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}, 1);

// ─── Remove noise from React page <head> ─────────────────────────────────────
add_action('init', function () {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'wp_shortlink_wp_head');
});
