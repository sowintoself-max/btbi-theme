<footer style="background:#0C563B;margin-top:80px;padding:32px;text-align:center">
    <p style="font-family:'Montserrat',sans-serif;font-size:12px;color:rgba(250,246,238,.6);margin:0">
        © <?php echo date('Y'); ?> The Best Travel Biz Institute™ · All rights reserved.
        &nbsp;·&nbsp; <a href="/" style="color:#C9A961;text-decoration:none">Back to the Institute</a>
    </p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
