<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header style="background:#0C563B;padding:0 32px">
    <div style="max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;height:64px">
        <a href="/" style="display:flex;align-items:center;gap:10px;text-decoration:none">
            <img src="<?php echo get_template_directory_uri(); ?>/react-app/logo.png" alt="The Best Travel Biz Institute" style="height:36px;width:auto">
            <span style="font-family:'Cinzel',serif;font-size:13px;letter-spacing:.08em;color:#FAF6EE;line-height:1.2">
                THE BEST TRAVEL BIZ<br><span style="color:#C9A961;font-size:11px">INSTITUTE™</span>
            </span>
        </a>
        <nav style="display:flex;gap:24px;align-items:center">
            <a href="/" style="color:#FAF6EE;text-decoration:none;font-size:12.5px;font-family:'Montserrat',sans-serif;opacity:.85">Home</a>
            <a href="/snapshot" style="color:#FAF6EE;text-decoration:none;font-size:12.5px;font-family:'Montserrat',sans-serif;opacity:.85">Snapshot™</a>
            <a href="/challenge" style="color:#FAF6EE;text-decoration:none;font-size:12.5px;font-family:'Montserrat',sans-serif;opacity:.85">14‑Day Challenge</a>
        </nav>
    </div>
</header>
