<?php
// Blog listing — used for /blog, /page/2, category archives, etc.
get_header('blog');
?>
<main style="max-width:860px;margin:80px auto;padding:0 32px;font-family:'Montserrat',sans-serif;color:#1a1a1a">
    <div style="border-bottom:1px solid #e0d9ce;padding-bottom:32px;margin-bottom:48px">
        <p style="font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#C9A961;margin:0 0 8px">The Institute</p>
        <h1 style="font-family:'Cinzel',serif;font-size:32px;font-weight:500;color:#0C563B;margin:0">
            <?php
            if (is_category()) {
                echo 'Category: ' . single_cat_title('', false);
            } elseif (is_search()) {
                echo 'Search: ' . get_search_query();
            } else {
                echo 'The Journal';
            }
            ?>
        </h1>
    </div>

    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <article style="margin-bottom:48px;padding-bottom:48px;border-bottom:1px solid #e0d9ce">
                <p style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#888;margin:0 0 10px">
                    <?php echo get_the_date('F j, Y'); ?>
                    <?php the_category(' · '); ?>
                </p>
                <h2 style="font-family:'Cinzel',serif;font-size:22px;font-weight:500;margin:0 0 12px;line-height:1.3">
                    <a href="<?php the_permalink(); ?>" style="color:#0C563B;text-decoration:none">
                        <?php the_title(); ?>
                    </a>
                </h2>
                <p style="font-size:15px;line-height:1.7;color:#444;margin:0 0 18px">
                    <?php echo wp_trim_words(get_the_excerpt(), 30, '…'); ?>
                </p>
                <a href="<?php the_permalink(); ?>" style="font-size:11.5px;letter-spacing:.1em;text-transform:uppercase;color:#C9A961;text-decoration:none;font-weight:600">
                    Continue Reading →
                </a>
            </article>
        <?php endwhile; ?>

        <div style="display:flex;gap:16px;margin-top:32px">
            <?php
            $prev = get_previous_posts_link('← Newer');
            $next = get_next_posts_link('Older →');
            $link_style = 'padding:10px 20px;background:#0C563B;color:#FAF6EE;text-decoration:none;font-size:12px;letter-spacing:.1em;text-transform:uppercase';
            if ($prev) echo '<a href="#" style="' . $link_style . '">' . $prev . '</a>';
            if ($next) echo '<a href="#" style="' . $link_style . '">' . $next . '</a>';
            ?>
        </div>

    <?php else : ?>
        <div style="text-align:center;padding:80px 0">
            <p style="font-family:'Cormorant Garamond',serif;font-size:24px;font-style:italic;color:#888">
                The Journal is coming soon.
            </p>
            <a href="/" style="display:inline-block;margin-top:24px;padding:14px 28px;background:#0C563B;color:#FAF6EE;text-decoration:none;font-size:11.5px;letter-spacing:.12em;text-transform:uppercase">
                Back to the Institute →
            </a>
        </div>
    <?php endif; ?>
</main>
<?php get_footer('blog'); ?>
