<?php
/*
Template Name: React App Page
Template Post Type: page
*/
// Assign this template to the WordPress pages for:
//   /snapshot  →  Page slug: snapshot
//   /snapshot-intake  →  Page slug: snapshot-intake
//   /challenge  →  Page slug: challenge
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class('btbi-react-page'); ?>>
<div id="root"></div>
<?php wp_footer(); ?>
</body>
</html>
