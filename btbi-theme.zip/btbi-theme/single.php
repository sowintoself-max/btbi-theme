<?php
// Single blog post template
get_header('blog');
?>
<main style="max-width:720px;margin:80px auto;padding:0 32px;font-family:'Montserrat',sans-serif;color:#1a1a1a">
    <?php while (have_posts()) : the_post(); ?>
        <p style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#888;margin:0 0 12px">
            <a href="/" style="color:#C9A961;text-decoration:none">The Best Travel Biz Institute</a>
            &nbsp;·&nbsp;
            <?php echo get_the_date('F j, Y'); ?>
        </p>
        <h1 style="font-family:'Cinzel',serif;font-size:30px;font-weight:500;color:#0C563B;margin:0 0 32px;line-height:1.25">
            <?php the_title(); ?>
        </h1>

        <?php if (has_post_thumbnail()) : ?>
            <figure style="margin:0 0 40px">
                <?php the_post_thumbnail('large', ['style' => 'width:100%;height:auto']); ?>
            </figure>
        <?php endif; ?>

        <div style="font-size:16px;line-height:1.8;color:#333">
            <?php the_content(); ?>
        </div>

        <div style="margin-top:56px;padding-top:32px;border-top:1px solid #e0d9ce">
            <a href="/blog" style="font-size:11.5px;letter-spacing:.1em;text-transform:uppercase;color:#C9A961;text-decoration:none;font-weight:600">
                ← Back to The Journal
            </a>
        </div>
    <?php endwhile; ?>
</main>
<?php get_footer('blog'); ?>
