<?php
// Homepage — serves the React app shell.
// WordPress Settings > Reading must be set to a static front page.
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Executive education for travel entrepreneurs. Stop renting a desk — learn how to own the building with structure, ownership, and systems that build long-term wealth.">
    <?php wp_head(); ?>
</head>
<body <?php body_class('btbi-react-page'); ?>>
<div id="root"></div>
<?php wp_footer(); ?>
</body>
</html>
